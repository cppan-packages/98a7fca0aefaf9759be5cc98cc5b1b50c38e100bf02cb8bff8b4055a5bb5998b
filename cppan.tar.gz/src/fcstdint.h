#ifndef _FONTCONFIG_SRC_FCSTDINT_H
#define _FONTCONFIG_SRC_FCSTDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "fontconfig 2.12.4"
/* generated using gnu compiler gcc (GCC) 6.3.1 20161221 (Red Hat 6.3.1-1) */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
